package com.example.hp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.NavController
import androidx.navigation.NavHost
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.onNavDestinationSelected
import androidx.navigation.ui.setupActionBarWithNavController
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //we have to do it lick that, otherwise it crashes
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.findNavController()

        //needed because it is a custom actionbar, not the default one
        //toolbar = id in xml file
        setSupportActionBar(toolbar)
        //connects actionbar to navController, adds all icons we need on actionbar example: backbutton
        setupActionBarWithNavController(navController)
    }
    //create menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.options_menu, menu)
        //return true to make menu visible
        return true
    }

    //navigate to destination linked to the item clicked in the menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //if id match in options_menu xml file and the id of the fragment (= fragment_Settings), navigate to fragment
        return item.onNavDestinationSelected(navController) || super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}