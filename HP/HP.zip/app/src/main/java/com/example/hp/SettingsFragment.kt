package com.example.hp

import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_settings) {
}